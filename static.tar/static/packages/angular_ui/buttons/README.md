There are 2 directives that can make a group of buttons to behave like a set of checkboxes or radio buttons.

